(() => {
  const main = document.querySelector('[data-gallery-main]');
  document.querySelectorAll('[data-gallery-thumb]').forEach(button => {
    button.addEventListener('click', () => {
      if (!main) return;
      main.src = button.dataset.galleryThumb;
      document.querySelectorAll('[data-gallery-thumb]').forEach(item => item.classList.remove('is-active'));
      button.classList.add('is-active');
    });
  });


  const form = document.querySelector('.lumia-product-form');
  if (form) {
    form.addEventListener('change', () => {
      if (form.reportValidity()) {
        try { salla.product.getPrice(new FormData(form)); } catch (error) { console.warn('Price refresh failed', error); }
      }
    });
  }

  const updatePrice = (payload) => {
    const data = payload?.data || payload;
    if (!data) return;
    document.querySelectorAll('.total-price').forEach(el => { el.textContent = salla.money(data.price); });
    document.querySelectorAll('.before-price').forEach(el => {
      const onSale = data.has_sale_price && Number(data.regular_price) > Number(data.price);
      el.textContent = onSale ? salla.money(data.regular_price) : '';
      el.classList.toggle('is-hidden', !onSale);
    });
    document.querySelector('[data-product-out]')?.classList.add('is-hidden');
  };

  const markUnavailable = () => document.querySelector('[data-product-out]')?.classList.remove('is-hidden');

  if (window.salla) {
    try { salla.product.event.onPriceUpdated(updatePrice); } catch (error) { console.warn('Price listener unavailable', error); }
    try { salla.event.on('product::price.updated.failed', markUnavailable); } catch (error) { console.warn('Availability listener unavailable', error); }
  }
})();
