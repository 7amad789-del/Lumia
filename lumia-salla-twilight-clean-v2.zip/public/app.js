(() => {
  'use strict';

  const qs = (s, root = document) => root.querySelector(s);
  const qsa = (s, root = document) => Array.from(root.querySelectorAll(s));

  const menuButton = qs('[data-menu-toggle]');
  const menu = qs('[data-mobile-menu]');
  if (menuButton && menu) {
    menuButton.addEventListener('click', () => {
      menu.classList.toggle('is-open');
      menuButton.setAttribute('aria-expanded', menu.classList.contains('is-open') ? 'true' : 'false');
    });
  }

  qsa('.lumia-faq__item > button').forEach(button => {
    button.addEventListener('click', () => {
      const item = button.closest('.lumia-faq__item');
      const isOpen = item.classList.toggle('is-open');
      button.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
      const icon = button.querySelector('b');
      if (icon) icon.textContent = isOpen ? '−' : '+';
    });
  });

  qsa('[data-copy]').forEach(button => {
    button.addEventListener('click', async () => {
      const value = button.getAttribute('data-copy') || '';
      try {
        await navigator.clipboard.writeText(value);
        const old = button.innerHTML;
        button.textContent = 'تم نسخ الكود ✓';
        setTimeout(() => { button.innerHTML = old; }, 1600);
      } catch (error) {
        console.warn('Coupon copy failed', error);
      }
    });
  });

  window.addEventListener('scroll', () => {
    const header = qs('[data-lumia-header]');
    if (header) header.classList.toggle('is-scrolled', window.scrollY > 18);
  }, { passive: true });
})();
