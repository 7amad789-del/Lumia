(() => {
  const root = document.querySelector('[data-advisor]');
  if (!root) return;
  const pain = root.querySelector('[data-advisor-pain]');
  const area = root.querySelector('[data-advisor-area]');
  const result = root.querySelector('[data-advisor-result]');
  const button = root.querySelector('[data-advisor-submit]');
  const plans = {
    light: ['50° + اهتزاز خفيف', 'ابدئي بجلسة قصيرة واختاري أقل مستوى مريح.'],
    medium: ['55° + اهتزاز متوسط', 'ابدئي بدرجة متوسطة وعدّليها بحسب راحتك.'],
    strong: ['درجة مريحة + اهتزاز متدرج', 'لا ترفعي الحرارة مباشرة. ابدئي تدريجياً، وراجعي مختصاً عند الألم الشديد أو المستمر.']
  };
  button?.addEventListener('click', () => {
    const [title, text] = plans[pain.value] || plans.medium;
    const place = area.value === 'back' ? 'أسفل الظهر' : 'البطن';
    result.innerHTML = `<span>اقتراح مبدئي لمنطقة ${place}</span><h3>${title}</h3><p>${text}</p>`;
    result.classList.add('is-active');
  });
})();
