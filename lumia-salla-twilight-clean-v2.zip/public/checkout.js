document.addEventListener('DOMContentLoaded', () => {
  document.body.classList.add('lumia-checkout-ready');
});
